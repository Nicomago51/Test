// Copyright (c) 2015 YamaArashi

#ifndef JASC_PAL_H
#define JASC_PAL_H

void ReadJascPalette(char *path, struct Palette *palette);
void WriteJascPalette(char *path, struct Palette *palette);

#endif // JASC_PAL_H
