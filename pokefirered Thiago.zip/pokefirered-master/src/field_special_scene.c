#include "global.h"

static u32 FieldSpecialScene_Dummy0(void)
{
    return 0;
}

static void FieldSpecialScene_Dummy1(void)
{
}

static void FieldSpecialScene_Dummy2(void)
{
}

static void FieldSpecialScene_Dummy3(void)
{
}

void FieldCB_ShowPortholeView(void)
{
}

// From Hoenn's SS Tidal
void LookThroughPorthole(void)
{
}
