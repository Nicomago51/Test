#ifndef GUARD_ITEMFINDER_H
#define GUARD_ITEMFINDER_H

void ItemUseOnFieldCB_Itemfinder(u8 taskId);

#endif //GUARD_ITEMFINDER_H
