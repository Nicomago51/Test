#ifndef GUARD_FIELD_EFFECT_SCRIPTS_H
#define GUARD_FIELD_EFFECT_SCRIPTS_H

extern const u8 *const gFieldEffectScriptPointers[];

#endif //GUARD_FIELD_EFFECT_SCRIPTS_H
