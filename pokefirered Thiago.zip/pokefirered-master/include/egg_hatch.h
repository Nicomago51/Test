#ifndef GUARD_EGG_HATCH_H
#define GUARD_EGG_HATCH_H

#include "global.h"

void ScriptHatchMon(void);
void EggHatch(void);
u8 GetEggStepsToSubtract(void);

#endif // GUARD_EGG_HATCH_H
