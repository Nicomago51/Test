#ifndef GUARD_QUEST_LOG_BATTLE_H
#define GUARD_QUEST_LOG_BATTLE_H

#include "global.h"

void TrySetQuestLogBattleEvent(void);
void TrySetQuestLogLinkBattleEvent(void);

#endif // GUARD_QUEST_LOG_BATTLE_H
