#ifndef GUARD_BERRY_CRUSH_H
#define GUARD_BERRY_CRUSH_H

#include "main.h"

void StartBerryCrush(MainCallback callback);
void ShowBerryCrushRankings(void);

#endif // GUARD_BERRY_CRUSH_H
