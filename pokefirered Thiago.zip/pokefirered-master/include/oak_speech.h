#ifndef GUARD_OAK_SPEECH_H
#define GUARD_OAK_SPEECH_H

void StartNewGameScene(void);

#endif //GUARD_OAK_SPEECH_H
