#ifndef GUARD_WILD_POKEMON_AREA_H
#define GUARD_WILD_POKEMON_AREA_H

s32 GetSpeciesPokedexAreaMarkers(u16 species, struct Subsprite * subsprites);

#endif //GUARD_WILD_POKEMON_AREA_H
