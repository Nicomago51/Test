#ifndef GUARD_COORD_EVENT_WEATHER_H
#define GUARD_COORD_EVENT_WEATHER_H

void DoCoordEventWeather(u8 weatherId);

#endif //GUARD_COORD_EVENT_WEATHER_H
