#ifndef GUARD_INTRO_H
#define GUARD_INTRO_H

void CB2_InitCopyrightScreenAfterTitleScreen(void);
void CB2_InitCopyrightScreenAfterBootup(void);

#endif //GUARD_INTRO_H
