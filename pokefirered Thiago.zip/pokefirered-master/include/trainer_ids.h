#ifndef GUARD_TRAINER_IDS_H
#define GUARD_TRAINER_IDS_H

#include "global.h"

#define NO_OF_TRAINERS      854
#define TRAINER_ID_STEVEN   804

#endif // GUARD_TRAINER_IDS_H
