#ifndef GUARD_HALL_OF_FAME_H
#define GUARD_HALL_OF_FAME_H

#include "global.h"

void CB2_DoHallOfFameScreen(void);
void CB2_DoHallOfFameScreenDontSaveData(void);
void CB2_DoHallOfFamePC(void);
void CB2_InitHofPC(void);
void HallOfFamePCBeginFade(void);
void ReturnFromHallOfFamePC(void);

#endif // GUARD_HALL_OF_FAME_H
