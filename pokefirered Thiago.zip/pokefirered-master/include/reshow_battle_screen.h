#ifndef GUARD_RESHOW_BATTLE_SCREEN_H
#define GUARD_RESHOW_BATTLE_SCREEN_H

#include "global.h"

void ReshowBattleScreenDummy(void);
void ReshowBattleScreenAfterMenu(void);

#endif // GUARD_RESHOW_BATTLE_SCREEN_H
