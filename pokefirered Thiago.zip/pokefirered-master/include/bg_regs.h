#ifndef GUARD_BG_REGS_H
#define GUARD_BG_REGS_H

extern const u8 gBGControlRegOffsets[];
extern const u16 gOverworldBackgroundLayerFlags[];

#endif //GUARD_BG_REGS_H
