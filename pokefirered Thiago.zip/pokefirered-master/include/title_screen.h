#ifndef GUARD_TITLE_SCREEN_H
#define GUARD_TITLE_SCREEN_H

void CB2_InitTitleScreen(void);

#endif //GUARD_TITLE_SCREEN_H
