#ifndef GUARD_RESET_SAVE_HEAP_H
#define GUARD_RESET_SAVE_HEAP_H

void ReloadSave(void);

#endif //GUARD_RESET_SAVE_HEAP_H

