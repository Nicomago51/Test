#ifndef GUARD_FIELD_TASKS_H
#define GUARD_FIELD_TASKS_H

#include "global.h"

void ActivatePerStepCallback(u8);
void SetUpFieldTasks(void);

#endif // GUARD_FIELD_TASKS_H
